﻿Add-Type -AssemblyName System.Windows.Forms

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "Установка плагинов Obsidian"
Write-Host "==========================="
Write-Host ""

$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = "Выберите папку вашего хранилища Obsidian"
$dialog.ShowNewFolderButton = $false
$result = $dialog.ShowDialog()

if ($result -ne [System.Windows.Forms.DialogResult]::OK -or [string]::IsNullOrWhiteSpace($dialog.SelectedPath)) {
    Write-Host "Установка отменена."
    Read-Host "Нажмите Enter, чтобы закрыть окно"
    exit 0
}

$vault = $dialog.SelectedPath

if (-not (Test-Path (Join-Path $vault ".obsidian"))) {
    [System.Windows.Forms.MessageBox]::Show("В выбранной папке нет .obsidian - похоже, это не хранилище Obsidian, или оно ни разу не открывалось в приложении Obsidian.`n`nОткройте эту папку как хранилище в Obsidian хотя бы один раз, затем запустите установщик снова.", "Установка плагинов", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
    Read-Host "Нажмите Enter, чтобы закрыть окно"
    exit 1
}

Write-Host "Хранилище: $vault"
Write-Host ""

$pluginsTarget = Join-Path $vault ".obsidian\plugins"
New-Item -ItemType Directory -Force -Path $pluginsTarget | Out-Null

Write-Host "Копирую плагины..."
$pluginIds = @("smart-connections", "omnisearch", "templater-obsidian")
foreach ($p in $pluginIds) {
    $src = Join-Path $scriptDir ".obsidian\plugins\$p"
    $dst = Join-Path $pluginsTarget $p
    if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
    Copy-Item -Recurse -Force $src $dst
    Write-Host "  - $p"
}

Write-Host ""
Write-Host "Включаю плагины..."

$cpJsonPath = Join-Path $vault ".obsidian\community-plugins.json"
$existingIds = @()
if (Test-Path $cpJsonPath) {
    $content = Get-Content $cpJsonPath -Raw
    $existingIds = [regex]::Matches($content, '"([^"]*)"') | ForEach-Object { $_.Groups[1].Value }
}
$allIds = New-Object System.Collections.Generic.List[string]
foreach ($id in $existingIds) { $allIds.Add($id) }
foreach ($id in $pluginIds) {
    if (-not $allIds.Contains($id)) { $allIds.Add($id) }
}
$jsonLines = $allIds | ForEach-Object { "  `"$_`"" }
$json = "[`n" + ($jsonLines -join ",`n") + "`n]"
[System.IO.File]::WriteAllText($cpJsonPath, $json, (New-Object System.Text.UTF8Encoding $false))

Write-Host ""
Write-Host "Копирую шаблон заметки..."
$templatesTarget = Join-Path $vault "Templates"
New-Item -ItemType Directory -Force -Path $templatesTarget | Out-Null
$templatesSource = Join-Path $scriptDir "Templates"
Get-ChildItem -Path $templatesSource -File | ForEach-Object {
    $targetFile = Join-Path $templatesTarget $_.Name
    if (Test-Path $targetFile) {
        $base = [System.IO.Path]::GetFileNameWithoutExtension($_.Name)
        $ext = $_.Extension
        $newName = "$base (из установщика)$ext"
        Copy-Item -Force $_.FullName (Join-Path $templatesTarget $newName)
        Write-Host "  - в Templates уже есть файл `"$($_.Name)`", сохранён рядом как `"$newName`""
    } else {
        Copy-Item -Force $_.FullName $targetFile
        Write-Host "  - $($_.Name)"
    }
}

Write-Host ""
Write-Host "Готово!"

[System.Windows.Forms.MessageBox]::Show("Готово! Плагины установлены.`n`nТеперь полностью перезапустите Obsidian: закройте его полностью и откройте снова.", "Установка плагинов", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null

Read-Host "Нажмите Enter, чтобы закрыть окно"
