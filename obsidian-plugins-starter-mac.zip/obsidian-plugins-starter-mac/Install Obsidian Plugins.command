#!/bin/bash
# Устанавливает Smart Connections, Templater и Omnisearch в выбранное хранилище Obsidian.

DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Установка плагинов Obsidian"
echo "==========================="
echo ""

VAULT=$(osascript -e '
try
  return POSIX path of (choose folder with prompt "Выберите папку вашего хранилища Obsidian")
on error
  return ""
end try')

if [ -z "$VAULT" ]; then
  echo "Установка отменена."
  read -n 1 -s -r -p $'Нажмите любую клавишу, чтобы закрыть окно...\n'
  exit 0
fi

VAULT="${VAULT%/}"

if [ ! -d "$VAULT/.obsidian" ]; then
  osascript -e 'display dialog "В выбранной папке нет .obsidian — похоже, это не хранилище Obsidian, или оно ни разу не открывалось в приложении Obsidian.\n\nОткройте эту папку как хранилище в Obsidian хотя бы один раз, затем запустите установщик снова." buttons {"Понятно"} default button 1 with icon caution with title "Установка плагинов"'
  read -n 1 -s -r -p $'Нажмите любую клавишу, чтобы закрыть окно...\n'
  exit 1
fi

echo "Хранилище: $VAULT"
echo ""

mkdir -p "$VAULT/.obsidian/plugins"

echo "Копирую плагины..."
for p in smart-connections omnisearch templater-obsidian; do
  rm -rf "$VAULT/.obsidian/plugins/$p"
  cp -R "$DIR/.obsidian/plugins/$p" "$VAULT/.obsidian/plugins/$p"
  echo "  - $p"
done

echo ""
echo "Включаю плагины..."

CPJSON="$VAULT/.obsidian/community-plugins.json"
NEW_IDS="smart-connections templater-obsidian omnisearch"

if [ -f "$CPJSON" ]; then
  EXISTING=$(grep -o '"[^"]*"' "$CPJSON" | tr -d '"')
else
  EXISTING=""
fi

ALL_IDS="$EXISTING"
for id in $NEW_IDS; do
  if ! grep -qx "$id" <<< "$EXISTING"; then
    ALL_IDS="$ALL_IDS
$id"
  fi
done

{
  echo "["
  first=1
  while IFS= read -r id; do
    [ -z "$id" ] && continue
    if [ $first -eq 1 ]; then first=0; else echo ","; fi
    printf '  "%s"' "$id"
  done <<< "$ALL_IDS"
  echo ""
  echo "]"
} > "$CPJSON"

echo ""
echo "Копирую шаблон заметки..."
mkdir -p "$VAULT/Templates"
for f in "$DIR/Templates/"*; do
  name="$(basename "$f")"
  target="$VAULT/Templates/$name"
  if [ -e "$target" ]; then
    base="${name%.*}"
    ext="${name##*.}"
    cp "$f" "$VAULT/Templates/${base} (из установщика).${ext}"
    echo "  - в Templates уже есть файл \"$name\", сохранён рядом как \"${base} (из установщика).${ext}\""
  else
    cp "$f" "$target"
    echo "  - $name"
  fi
done

echo ""
echo "Готово!"

osascript -e 'display dialog "Готово! Плагины установлены.\n\nТеперь полностью перезапустите Obsidian: закройте через Cmd+Q (не просто закрытие окна) и откройте снова." buttons {"Отлично"} default button 1 with icon note with title "Установка плагинов"'

read -n 1 -s -r -p $'Нажмите любую клавишу, чтобы закрыть окно...\n'
